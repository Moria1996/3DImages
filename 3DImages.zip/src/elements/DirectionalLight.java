package elements;

import java.awt.Color;
import primitives.Point3D;
import primitives.Vector;

public class DirectionalLight extends Light{
	private Vector direction;
	public DirectionalLight(Color intensity, Vector direction) {
		super(intensity);
		this.direction=new Vector(direction);
	}	
	public Vector getDirection() {
		return direction;
	}
	public void setDirection(Vector direction) {
		this.direction = direction;
	}
	public Color getIntensity(Point3D point) {
		return this.intensity;
	}
	public Vector getL(Point3D point) {
		return this.direction;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DirectionalLight other = (DirectionalLight) obj;
		if (direction == null) {
			if (other.direction != null)
				return false;
		} else if (!direction.equals(other.direction))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "direction=" + this.direction + ", intensity=" + this.intensity;
	}
}
