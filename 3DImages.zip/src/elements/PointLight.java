package elements;

import java.awt.Color;

import primitives.Point3D;
import primitives.Vector;

public class PointLight extends Light{
	protected Point3D position;
	protected double kC;
	protected double kL;
	protected double kQ;
	public PointLight(Color intensity, Point3D position, double kC, double kL, double kQ) {
		super(intensity);
		this.position=new Point3D(position);
		this.kC=kC;
		this.kL=kL;
		this.kQ=kQ;
	}
	public Point3D getPosition() {
		return position;
	}
	public void setPosition(Point3D position) {
		this.position = position;
	}
	public double getkC() {
		return kC;
	}
	public void setkC(double kC) {
		this.kC = kC;
	}
	public double getkL() {
		return kL;
	}
	public void setkL(double kL) {
		this.kL = kL;
	}
	public double getkQ() {
		return kQ;
	}
	public void setkQ(double kQ) {
		this.kQ = kQ;
	}
	public Color getIntensity(Point3D point) throws Exception {
		double distance=this.position.distance(point);
		double k=1/(kC+(kL*distance)+(kQ*Math.pow(distance, 2)));
		return this.mulColorNum(intensity, k);
	}
	public Vector getL(Point3D point) {
		try {
			return new Vector(point.subtract(this.position).normalize());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PointLight other = (PointLight) obj;
		if (Double.doubleToLongBits(kC) != Double.doubleToLongBits(other.kC))
			return false;
		if (Double.doubleToLongBits(kL) != Double.doubleToLongBits(other.kL))
			return false;
		if (Double.doubleToLongBits(kQ) != Double.doubleToLongBits(other.kQ))
			return false;
		if (position == null) {
			if (other.position != null)
				return false;
		} else if (!position.equals(other.position))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "position=" + position + ", kC=" + kC + ", kL=" + kL + ", kQ=" + kQ + ", intensity="+ intensity;
	}
}
