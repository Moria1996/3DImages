package elements;

import java.awt.Color;
import primitives.Point3D;
import primitives.Vector;

public abstract class Light {
	protected Color intensity;//attribute
	public Light(Color intensity) {//constructor
		this.intensity=new Color(intensity.getRGB());
	}
	// getter and setter
	public Color getIntensity() {
		return intensity;
	}
	public void setIntensity(Color intensity) {
		this.intensity = intensity;
	}
	public static Color mulColorNum(Color color, double number) {
		int r=(int) (color.getRed()*number);
		int g=(int)(color.getGreen()*number);
		int b=(int)(color.getBlue()*number);
		if(r>255)
			r=255;
		if(r<0)
			r=0;
		if(g>255)
			g=255;
		if(g<0)
			g=0;
		if(b>255)
			b=255;
		if(b<0)
			b=0;
		Color result = new Color(r,g,b);
		return result;
	}
	public static Color colorAddColor(Color color1, Color color2) {
		int r= color1.getRed()+color2.getRed();
		int g=color1.getGreen()+color2.getGreen();
		int b=color1.getBlue()+color2.getBlue();
		if(r>255)
			r=255;
		if(r<0)
			r=0;
		if(g>255)
			g=255;
		if(g<0)
			g=0;
		if(b>255)
			b=255;
		if(b<0)
			b=0;
		Color result = new Color(r,g,b);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Light other = (Light) obj;
		if (intensity == null) {
			if (other.intensity != null)
				return false;
		} else if (!intensity.equals(other.intensity))
			return false;
		return true;
	}
	public abstract Color getIntensity(Point3D point) throws Exception;
	public abstract Vector getL(Point3D point);
}
