package elements;

import java.awt.Color;
import primitives.Point3D;
import primitives.Vector;

public class AmbientLight extends Light{
	private double ka;//attribute
	public AmbientLight(Color intensity, double ka) {//constructor
		super(intensity);
		this.ka=ka;
	}
	public AmbientLight() {//constructor
		super(new Color(0,0,0));
		this.ka=0.1;
	}
	//getter and setter
	public double getKa() {
		return ka;
	}
	public void setKa(double ka) {
		this.ka = ka;
	}
	public  Color getIntensity(Point3D point) {
		return mulColorNum(this.intensity, this.ka);	
	}
	public Vector getL(Point3D point) {
		return new Vector();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		AmbientLight other = (AmbientLight) obj;
		if (Double.doubleToLongBits(ka) != Double.doubleToLongBits(other.ka))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ka=" + this.ka + ", intensity=" + this.intensity;
	}
}
