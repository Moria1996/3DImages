package elements;

import java.awt.Color;

import primitives.Point3D;
import primitives.Vector;

public class SpotLight extends PointLight{
	private Vector direction;
	public SpotLight(Color intensity, Point3D position, Vector direction, double kC, double kL, double kQ) {
		super(intensity, position, kC, kL, kQ);
		this.direction=new Vector(direction);
	}
	public Vector getDirection() {
		return direction;
	}
	public void setDirection(Vector direction) {
		this.direction = direction;
	}
	public Color getIntensity(Point3D point) throws Exception {
		double distance=this.position.distance(point);
		double k=1/(kC+(kL*distance)+(kQ*Math.pow(distance, 2)));
		Color color=this.mulColorNum(intensity, k);
		double calc=Math.max(0, this.direction.dotProduct(this.getL(point).normalize()));
		return this.mulColorNum(color, calc);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		SpotLight other = (SpotLight) obj;
		if (direction == null) {
			if (other.direction != null)
				return false;
		} else if (!direction.equals(other.direction))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "direction=" + direction + ", position=" + position + ", kC=" + kC + ", kL=" + kL + ", kQ="
				+ kQ + ", intensity=" + intensity;
	}
}
