package elements;

import primitives.*;

public class Camera {
	//attributes for Camera class
	private Point3D p0;
	private Vector vUp;
	private Vector vRight;
	private Vector vTo;
	public Camera(Point3D p0, Vector vTo, Vector vUp) throws Exception {//constructor
		this.p0=new Point3D(p0);
		this.vTo=new Vector(vTo);
		this.vUp=new Vector(vUp);
		this.vRight=new Vector(vTo.crossProduct(vUp));//calculate vRight
	}
	public Camera(Camera camera) {//copy constructor
		this.p0=new Point3D(camera.p0);
		this.vTo=new Vector(camera.vTo);
		this.vUp=new Vector(camera.vUp);
		this.vRight=new Vector(camera.vRight);
	}
	public Camera() {//default constructor
		this.p0=new Point3D();
		this.vUp=new Vector();
		this.vRight=new Vector();
		this.vTo=new Vector();
	}
	//getters and setters
	public Point3D getP0() {
		return this.p0;
	}
	public void setP0(Point3D p0) {
		this.p0 = p0;
	}
	public Vector getvUp() {
		return this.vUp;
	}
	public void setvUp(Vector vUp) {
		this.vUp = vUp;
	}
	public Vector getvRight() {
		return this.vRight;
	}
	public void setvRight(Vector vRight) {
		this.vRight = vRight;
	}
	public Vector getvTo() {
		return this.vTo;
	}
	public void setvTo(Vector vTo) {
		this.vTo = vTo;
	}
	@Override
	public boolean equals(Object obj) {//equals method
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Camera other = (Camera) obj;
		if (p0 == null) {
			if (other.p0 != null)
				return false;
		} else if (!p0.equals(other.p0))
			return false;
		if (vRight == null) {
			if (other.vRight != null)
				return false;
		} else if (!vRight.equals(other.vRight))
			return false;
		if (vTo == null) {
			if (other.vTo != null)
				return false;
		} else if (!vTo.equals(other.vTo))
			return false;
		if (vUp == null) {
			if (other.vUp != null)
				return false;
		} else if (!vUp.equals(other.vUp))
			return false;
		return true;
	}
	//method that returns the ray that go through a specific pixel
	public Ray constructRayThroughPixel(int nX, int nY, int j, int i,
			double screenDistance, double screenWidth, double screenHeight) throws Exception {
		Point3D pC=new Point3D(this.p0.add(this.vTo.scale(screenDistance)));//calculate pC
		double rX=screenWidth/nX;//calculate rX
		double rY=screenHeight/nY;//calculate rY
		double yI=(i-nY/2.0)*rY+rY/2;//calculate yI
		double xJ =(j-nX/2.0)*rX+rX/2;//calculate xJ
		Point3D pIJ=new Point3D(pC);
		//calculate pIJ
		if(xJ!=0&&yI!=0) 
			pIJ=pIJ.add(this.vRight.scale(xJ).subtract(this.vUp.scale(yI)));
		else if(xJ!=0)
			pIJ=pIJ.add(this.vRight.scale(xJ));
		else if(yI!=0)
			pIJ=pIJ.add(this.vUp.scale(-yI));		
		Vector vIJ=new Vector(pIJ.subtract(this.p0));//calculate vIJ
		Ray resultRay=new Ray(this.p0,vIJ.normalize());//calculate resultRay
		return resultRay;
	}
	public String toString() {//toString method
		return "p0:"+this.p0+"vRight:"+this.vRight+"vUp:"+this.vUp+"vTo:"+this.vTo;
	}
}
