package scene;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import elements.AmbientLight;
import elements.Camera;
import elements.Light;
import geometries.Geometry;
public class Scene {
	//attributes for class Scene
	private String name;
	private List<Geometry> geometries;
	private Camera camera;
	private double screenDistance;
	private Color background; 
	//not yet in constructor
	private AmbientLight ambientLight;
	private List <Light> lights;
	public Scene(String name) {
		this.name=name;
		this.geometries=new ArrayList<Geometry>();
		this.camera=new Camera();
		this.ambientLight=new AmbientLight();
		this.lights=new ArrayList<Light>();
	}
	public Scene(String name, ArrayList<Geometry> geometries, double screenDistance, Color background )
				throws Exception {//constructor
		this.name=new String(name);
		this.geometries=new ArrayList<Geometry>(geometries);
		this.camera=new Camera(camera);
		this.screenDistance=screenDistance;
		this.background=new Color(background.getRGB());
	}
	public Scene() {//default constructor
		this.name=new String();
		this.geometries=new ArrayList<Geometry>();
		this.camera=new Camera();
		this.screenDistance=0;
		this.background=new Color(0,0,0);
	}
	public Scene(Scene scene) {//copy constructor
		this.name=new String(scene.name);
		this.geometries=new ArrayList<Geometry>(scene.geometries);
		this.camera=new Camera(scene.camera);
		this.screenDistance=scene.screenDistance;
		this.background=new Color(scene.background.getRGB());
		this.ambientLight=scene.ambientLight;
		this.lights=scene.lights;
	}
	//getters and setters
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Geometry> getGeometries() {
		return this.geometries;
	}
	public void setGeometries(ArrayList<Geometry> shapes) {
		this.geometries = shapes;
	}
	public Camera getCamera() {
		return camera;
	}
	public void setCamera(Camera camera) {
		this.camera = camera;
	}
	public double getScreenDistance() {
		return this.screenDistance;
	}
	public void setScreenDistance(double screenDistance) {
		this.screenDistance = screenDistance;
	}
	public Color getBackground() {
		return this.background;
	}
	public void setBackground(Color background) {
		this.background = background;
	}
	
	public AmbientLight getAmbientLight() {
		return ambientLight;
	}
	public void setAmbientLight(AmbientLight ambientLight) {
		this.ambientLight = ambientLight;
	}
	public List<Light> getLights() {
		return lights;
	}
	public void setLights(List<Light> lights) {
		this.lights = lights;
	}
	//equals and toString deleted
	public void addGeometry(Geometry geometry) {//addGeometry method
		this.geometries.add(geometry);
	}
	public void addLight(Light light) {
		this.lights.add(light);
	}
}
