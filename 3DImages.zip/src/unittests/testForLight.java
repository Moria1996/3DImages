package unittests;

import java.awt.Color;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import elements.AmbientLight;
import elements.Camera;
import elements.PointLight;
import elements.SpotLight;
import geometries.Geometry;
import geometries.Sphere;
import geometries.Triangle;
import primitives.Material;
import primitives.Point3D;
import primitives.Vector;
import renderer.ImageWriter;
import renderer.Renderer;
import scene.Scene;


public class testForLight {
	@Test
	public void pointLightTest() throws Exception{		
		Scene scene = new Scene("pointLightTest2");
		scene.setBackground(new Color(0, 0, 0));
		scene.setCamera(new Camera( new Point3D(0, 0, 0),new Vector(0.0, 0.0, 1.0),new Vector(0,-1, 0.0)));
		scene.setScreenDistance(200);
		scene.setAmbientLight(new AmbientLight(new Color(100, 100, 100), 0.1));
		Material m1=new Material(1,1,1);
		Material m2=new Material(1,1,20);
		Sphere sphere = new Sphere(600, new Point3D(0.0, 0.0, 1000),new Color(255, 0, 100));
		sphere.setMaterial(m2);
		scene.addGeometry(sphere);
		scene.addLight(new PointLight(new Color(255, 100, 100), new Point3D(200, -200, 100),  0, 0.000001, 0.0000005));		
		ImageWriter imageWriter = new ImageWriter("PointTest", 500, 500, 500, 500);		
		Renderer render = new Renderer(imageWriter, scene);		
		render.renderImage();		
	}
	@Test
	public void testSpot() throws Exception {
		Scene scene = new Scene("Test scene");
		scene.setCamera(new Camera(new Point3D(0, 0, -200), new Vector(0, 0, 1), new Vector(0, -1, 0)));
		scene.setScreenDistance(200); //
		scene.setBackground(Color.BLACK);
		scene.setAmbientLight(new AmbientLight(Color.WHITE,0.15));
		Geometry sphere = new Sphere(500, new Point3D(0, 0, 500),Color.BLUE); 
		sphere.setMaterial(new Material(1,1,100));
		scene.addGeometry(sphere);
		scene.addLight(new SpotLight(new Color(100, 200, 100), new Point3D(-200, 200, -250),new Vector(3,-1,2),  1, 0.00001, 0.000005));	
		ImageWriter imageWriter = new ImageWriter("SpotTest", 500, 500, 500, 500);		
		Renderer render = new Renderer(imageWriter, scene);
		render.renderImage();
	}

}
