package unittests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import org.junit.jupiter.api.Test;

import primitives.*;

class TestPrimitives {
	
	@Test
	public void testCoordinate() {//test for Coordinate class
		Coordinate c=new Coordinate(4);//create object
		assertEquals(c,new Coordinate(4));	//check equals method
		System.out.println(c);
	}
	@Test
	public void testPoint3D() {//test for Point3D class
		//create object
		Point3D p=new Point3D(new Coordinate (1),new Coordinate (0),new Coordinate (2));		
		assertEquals(p,new Point3D(new Coordinate (1),new Coordinate (0),new Coordinate (2)));//check equals method
		System.out.println(p);		
	}
	@Test
	public void testVector() {//test for Vector class
		//create object
		Vector v=new Vector(new Point3D(new Coordinate (4),new Coordinate (1),new Coordinate (0)));
		Vector v2=new Vector(new Point3D(new Coordinate (1.5),new Coordinate (-3.5),new Coordinate (5.5)));
		assertEquals(v,new Vector(new Point3D(new Coordinate (4),new Coordinate (1),new Coordinate (0))));//check equals method
		System.out.println(v);
	} 
	@Test
	public void testRay() {//test for Ray class
		//create objects for Ray
		Vector v=new Vector(new Point3D(new Coordinate (4),new Coordinate (1),new Coordinate (0)));
		Point3D p=new Point3D(new Coordinate (1),new Coordinate (0),new Coordinate (2));
		Ray r=new Ray(p,v);
		assertEquals(r,new Ray(p,v));//check equals method
		System.out.println(r);
	}
}
