package unittests;

import java.awt.Color;

import org.junit.jupiter.api.Test;

import renderer.ImageWriter;

class testImageWriter3 {

    @Test
    public void test() {
        ImageWriter imageWriter = new ImageWriter("imgWriterTest3", 1600, 1000, 800, 500);
        int nX = imageWriter.getNx();
        int nY = imageWriter.getNy();
        for (int i = 0; i < nY; ++i)// back round in white
            for (int j = 0; j < nX; ++j) 
                imageWriter.writePixel(j, i, new Color(255,255,255));   
        for (int i = 0; i < 50; ++i)// sky in blue
            for (int j = 0; j < nX; ++j) 
            	  imageWriter.writePixel(j, i, new Color(0,128,255));
        for (int i = 400; i < nY; ++i)// grass in green
            for (int j = 0; j < nX; ++j) 
            	  imageWriter.writePixel(j, i, new Color(102,204,0));
        for (int i = 50; i < 100; ++i)// sun in yellow
            for (int j = 0; j < 50; ++j) 
            	  imageWriter.writePixel(j, i, new Color(255,255,0));
        //flower
        for (int j = 200; j < 203; ++j) 
        	for (int i = 400; i >300; --i) 
        		imageWriter.writePixel(j, i, new Color(0,102,0));
        for (int i = 300; i < 320; ++i)
            for (int j = 190; j < 210; ++j) 
            	  imageWriter.writePixel(j, i, new Color(255,255,0));
        for (int i = 280; i < 300; ++i)
            for (int j = 190; j < 210; ++j) 
            	  imageWriter.writePixel(j, i, new Color(255,0,127));
        for (int i = 320; i < 340; ++i)
            for (int j = 190; j < 210; ++j) 
            	  imageWriter.writePixel(j, i, new Color(255,0,127));
        for (int i = 300; i < 320; ++i)
            for (int j = 170; j < 190; ++j) 
            	  imageWriter.writePixel(j, i, new Color(255,0,127));
        for (int i = 300; i < 320; ++i)
            for (int j = 210; j < 230; ++j) 
            	  imageWriter.writePixel(j, i, new Color(255,0,127));
        imageWriter.writeToImage();
    }
}