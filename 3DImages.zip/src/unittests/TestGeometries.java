package unittests;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;

import org.junit.jupiter.api.Test;

import geometries.*;
import primitives.*;
class TestGeometries {

	@Test
	public void testTriangle() throws Exception {//test for Triangle class
		//create objects for Triangle
		Point3D p1=new Point3D(new Coordinate (1),new Coordinate (0),new Coordinate (2));
		Point3D p2=new Point3D(new Coordinate (2),new Coordinate (1),new Coordinate (2));
		Point3D p3=new Point3D(new Coordinate (1),new Coordinate (-1),new Coordinate (2));
		Triangle t=new Triangle (p1,p2,p3, new Color(0,0,0));
		assertFalse(!t.equals(new Triangle (p1,p2,p3, new Color(0,0,0))));//check equals method
		System.out.println(t);
	}
	@Test
	public void testPlane()  {//test for Plane class
		//create objects for Plane
		Point3D p=new Point3D(new Coordinate (1),new Coordinate (0),new Coordinate (2));
		Vector v1=new Vector(p);
		Plane plane=new Plane(p,v1, new Color(0,0,0));
		Plane plane2=new Plane(plane.getQ(),plane.getN(), new Color(0,0,0));
		assertFalse(!plane.equals(plane2));//check equals method
		System.out.println(plane);
	}
	@Test
	public void testSphere()  {//test for Sphere class
		//create objects
		Sphere s1 =new Sphere (2,new Point3D(), new Color(0,0,0));
		Sphere s2 =new Sphere (2,new Point3D(new Coordinate (1),new Coordinate (0),new Coordinate (2)), new Color(0,0,0));
		assertFalse(s1.equals(s2));//check equals method
		System.out.println(s1);
	}
	@Test
	public void testCylinder()  {//test for Cylinder class
		//create objects for Cylinder
		Vector v=new Vector(new Point3D(new Coordinate (4),new Coordinate (1),new Coordinate (0)));
		Point3D p=new Point3D(new Coordinate (1),new Coordinate (2),new Coordinate (3));
		Cylinder c=new Cylinder(3,new Ray(p,v),7, new Color(0,0,0));
		assertFalse(!c.equals(new Cylinder(3,new Ray(p,v),7, new Color(0,0,0))));//check equals method
		System.out.println(c);
	}
}
