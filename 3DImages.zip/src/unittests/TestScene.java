package unittests;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import geometries.*;
import primitives.Coordinate;
import primitives.Point3D;
import scene.Scene;

class TestScene {
	@Test
	public void testScene() throws Exception {//test for Scene class
		//create objects for Scene
		ArrayList<Geometry> shapes=new ArrayList<Geometry>();
		Point3D p1=new Point3D(new Coordinate (1),new Coordinate (0),new Coordinate (2));
		Point3D p2=new Point3D(new Coordinate (2),new Coordinate (1),new Coordinate (2));
		Point3D p3=new Point3D(new Coordinate (1),new Coordinate (-1),new Coordinate (2));
		shapes.add(new Triangle (p1,p2,p3, new Color(0,0,0)));
		shapes.add(new Plane ());
		Scene s=new Scene("example scene",shapes,0, new Color(0,0,0));
		assertFalse(!s.equals(new Scene("example scene",shapes,0,new Color(0,0,0))));//check equals method
		System.out.println(s);
	}

}
