package unittests;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;

import org.junit.jupiter.api.Test;

import elements.AmbientLight;
import elements.Camera;
import elements.PointLight;
import geometries.Sphere;
import geometries.Triangle;
import primitives.Material;
import primitives.Point3D;
import primitives.Vector;
import renderer.ImageWriter;
import renderer.Renderer;
import scene.Scene;

class pictures {

	@Test
	void test() throws Exception {
		Scene scene = new Scene ("scene");
		scene.setBackground(new Color(255,255,255));
		scene.setCamera(new Camera( new Point3D(0, 0, 0),new Vector(0.0, 0.0, 1.0),new Vector(0,-1, 0.0)));
		scene.setScreenDistance(200);
		scene.setAmbientLight(new AmbientLight(new Color(100, 100, 100), 0.1));
		Material m1=new Material(1,1,1);
		Material m2=new Material(1,1,20);
		Triangle t1 = new Triangle (new Point3D(100, 225, 260),
				 new Point3D(-200, 125, 260),
				 new Point3D(-100, 225, 270), 
				new Color (158,25,200));
		Material m3=new Material(1,1,4);
		t1.setMaterial(m3);
		scene.addGeometry(t1);
		Sphere sphere = new Sphere (550, new Point3D(0.0, 0, 1000),new Color(0, 0, 100));
		Material m=new Material(1,1,20);
		sphere.setMaterial(m);
		scene.addGeometry(sphere);
		scene.addLight(new PointLight(new Color(255, 100, 100), new Point3D(-200, 200, -100),  0, 0.000001, 0.0000005));
		ImageWriter imageWriter = new ImageWriter("picture1", 500, 500, 500, 500);
		Renderer render = new Renderer(imageWriter, scene);
		render.renderImage();
	}

}
