package unittests;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Color;

import org.junit.jupiter.api.Test;

import elements.*;
import geometries.*;
import primitives.*;
import renderer.*;
import scene.Scene;

class testForShadow {

		@Test
		public void spotLightTest2() throws Exception{
			
			Scene scene = new Scene("pointLightTest");
			scene.setBackground(new Color(100, 0, 10));
			scene.setCamera(new Camera( new Point3D(0, 0, 0),new Vector(0.0, 0.0, 1.0),new Vector(0,-1, 0.0)));
			scene.setScreenDistance(200);
			scene.setAmbientLight(new AmbientLight(new Color(255, 255, 255), 0.1));
			Sphere sphere = new Sphere (550, new Point3D(0.0, 0, 1000),new Color(0, 0, 100));
			Material m=new Material(1,1,20);
			sphere.setMaterial(m);
			scene.addGeometry(sphere);
			scene.addLight(new PointLight(new Color(255, 100, 100), new Point3D(-200, 200, -100),  0, 0.000001, 0.0000005));
	
			Triangle triangle =new Triangle(new Point3D(-125, 225, 260),
					 new Point3D(-225, 125, 260),
					 new Point3D(-300, 225, 270),
					 new Color (0, 0, 100));
			
			Material m2=new Material(1,1,4);
			triangle.setMaterial(m2);
			scene.addGeometry(triangle);
			
			ImageWriter imageWriter = new ImageWriter("Point test with shadow", 500, 500, 500, 500);
			Renderer render = new Renderer(imageWriter, scene);
			render.renderImage();
			
		}
		@Test
		public void twoTriangles() throws Exception{
			
			Scene scene = new Scene("twoTriangles");
			scene.setBackground(new Color(0, 100, 50));
			scene.setCamera(new Camera( new Point3D(0, 0, 0),new Vector(0.0, 0.0, 1.0),new Vector(0,-1, 0.0)));
			scene.setScreenDistance(100);
			scene.setAmbientLight(new AmbientLight(new Color(100, 200, 100), 0.1));

			Triangle triangle1 = new Triangle(new Point3D(-300, 0, 400),
					 						 new Point3D(300, 0, 400),
					 						 new Point3D(0, -600, 400),
					 						 new Color (0, 0, 100));

			Triangle triangle2 = new Triangle(new Point3D(-100, 100, 100),
					 							new Point3D(50, 100, 100),
					 							new Point3D(0, -100, 100),
					 							new Color (100, 100, 0));

			Material m1=new Material(1,1,20);
			triangle1.setMaterial(m1);
			triangle2.setMaterial(m1);
			scene.addGeometry(triangle1);
			scene.addGeometry(triangle2);
		
			scene.addLight(new SpotLight(new Color(255, 100, 100), new Point3D(0, 200, 0), new Vector(0,-100,150), 0, 0.000001, 0.0000005));
		
			ImageWriter imageWriter = new ImageWriter("spotLightWithShadow", 500, 500, 500, 500);
			
			Renderer render = new Renderer(imageWriter, scene);
			
			render.renderImage();
			
		}
	}
