package unittests;

import java.awt.Color;

import org.junit.jupiter.api.Test;

import renderer.ImageWriter;

class testImageWriter2 {

    @Test
    public void test() {
        ImageWriter imageWriter = new ImageWriter("imgWriterTest2", 1600, 1000, 800, 500);
        int nX = imageWriter.getNx();
        int nY = imageWriter.getNy();
        for (int i = 0; i < nY; ++i)// back round in white
            for (int j = 0; j < nX; ++j) 
                imageWriter.writePixel(j, i, new Color(255,255,255));   
        for (int i = 0; i < 50; ++i)// sky in blue
            for (int j = 0; j < nX; ++j) 
            	  imageWriter.writePixel(j, i, new Color(0,128,255));
        for (int i = 400; i < nY; ++i)// grass in green
            for (int j = 0; j < nX; ++j) 
            	  imageWriter.writePixel(j, i, new Color(102,204,0));
        for (int i = 50; i < 100; ++i)// sun in yellow
            for (int j = 0; j < 50; ++j) 
            	  imageWriter.writePixel(j, i, new Color(255,255,0));
        for (int j = 200; j < 400; ++j) //bush in green
        	for (int i = 400; i >300; --i) 
        		imageWriter.writePixel(j, i, new Color(0,102,0));
        for (int j = 200; j < 220; ++j) //apples in red
        	for (int i = 350; i >330; --i) 
        		imageWriter.writePixel(j, i, new Color(255,0,0));
        for (int j = 250; j < 270; ++j) //apples in red
        	for (int i = 390; i >370; --i) 
        		imageWriter.writePixel(j, i, new Color(255,0,0));
        for (int j = 300; j < 320; ++j) //apples in red
        	for (int i = 350; i >330; --i) 
        		imageWriter.writePixel(j, i, new Color(255,0,0));
        for (int j = 350; j < 370; ++j) //apples in red
        	for (int i = 390; i >370; --i) 
        		imageWriter.writePixel(j, i, new Color(255,0,0));
        imageWriter.writeToImage();
    }
}