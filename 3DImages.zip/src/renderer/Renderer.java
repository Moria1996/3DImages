package renderer;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import elements.Light;
import geometries.GeoPoint;
import geometries.Geometry;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;
import scene.Scene;

public class Renderer {
	//attributes
	private Scene scene;
	private ImageWriter imageWriter;
	private static final double EPS = 0.1;
	public Renderer(ImageWriter imageWriter,Scene scene) {//constructor
		this.scene=new Scene(scene);
		this.imageWriter=new ImageWriter(imageWriter.getImageName(), imageWriter.getWidth(), imageWriter.getHeight()
				,imageWriter.getNx(),imageWriter.getNy());
	}
	// getters and setters
	public Scene getScene() {
		return scene;
	}
	public void setScene(Scene scene) {
		this.scene = scene;
	}
	public ImageWriter getImageWriter() {
		return imageWriter;
	}
	public void setImageWriter(ImageWriter imageWriter) {
		this.imageWriter = imageWriter;
	}
	public void renderImage() throws Exception {
		for(int i=0; i<imageWriter.getNy();i++) {
			for(int j=0;j<imageWriter.getNx();j++) {
				Ray ray=scene.getCamera().constructRayThroughPixel
						(imageWriter.getNx(), imageWriter.getNy(),j,i ,scene.getScreenDistance(),
								imageWriter.getWidth(), imageWriter.getHeight());
				List<GeoPoint> intersectionPoints =new ArrayList<GeoPoint>();
				intersectionPoints=getSceneRayIntersections(ray);
				if(intersectionPoints.isEmpty())
					imageWriter.writePixel(j, i, scene.getBackground());
				else {
					GeoPoint closestPoint = getClosestPoint(intersectionPoints);
					imageWriter.writePixel(j, i, calcColor(closestPoint));
				}					
			}
		}
		imageWriter.writeToImage();
	}
	private List<GeoPoint> getSceneRayIntersections(Ray ray) throws Exception{
		List<GeoPoint> intersectionPoints =new ArrayList<GeoPoint>();
		for (Geometry geometry : scene.getGeometries()) {
			if(geometry.findIntersections(ray)!=null) {
				List<GeoPoint> geometryIntersectionPoints =new ArrayList<GeoPoint>();
				for(int i=0;i<geometry.findIntersections(ray).size();i++) {
					GeoPoint geoPoint=new GeoPoint(geometry, geometry.findIntersections(ray).get(i));
					geometryIntersectionPoints.add(geoPoint);
				}
				intersectionPoints.addAll(geometryIntersectionPoints);
			}	
		}
		return intersectionPoints;
	}
	private GeoPoint getClosestPoint(List<GeoPoint> intersectionPoints) {
		double distance = Double.MAX_VALUE;
		Point3D p0=scene.getCamera().getP0();
		GeoPoint minDistancePoint = null;
		for (GeoPoint geoPoint : intersectionPoints) {
			if(p0.distance(geoPoint.getPoint())<distance) {
				minDistancePoint = new GeoPoint(geoPoint.getGeometry(),geoPoint.getPoint());
				distance = p0.distance(geoPoint.getPoint());
			}			
		}
		return minDistancePoint;
	}
	private Color calcDiffusiveComp(double kd, Vector n, Vector l, Color intensity) {
		double calc=kd*(n.dotProduct(l));
		return Light.mulColorNum(intensity, calc);
	}
	private Color calcSpecularComp(double ks, Vector v, Vector n,Vector l, int shininess, Color intensity) throws Exception {
		Vector r=(l.subtract(n.scale(l.dotProduct(n)*2))).normalize();
		return Light.mulColorNum(intensity, Math.pow(v.dotProduct(r), shininess)*ks);
	}
	private boolean shaded(Vector l, Point3D point, Vector n ) throws Exception {
		Vector lightDirection = new Vector(l.scale(-1)); 
		Vector epsVector = new Vector(n.scale(EPS));
	     Point3D newPoint = new Point3D(point.add(epsVector)); 
	     Ray shadowRay = new Ray(newPoint, lightDirection);
	     List<GeoPoint> intersectionPoints =getSceneRayIntersections(shadowRay);
	     if (intersectionPoints.isEmpty())
	    	return false;
	     return true;
	}
	private Color calcReflect(Ray inRay,Point3D point, Vector n) throws Exception {
		Vector v = inRay.getDirection();
	    Vector R=new Vector(v.subtract(n.scale(-2 * v.dotProduct(n))));
	    Ray reflectedRay = new Ray(point, R);
	    List<GeoPoint> reflectedIntersectionPoints =getSceneRayIntersections(reflectedRay);
	    if (!reflectedIntersectionPoints.isEmpty()) {
	    	GeoPoint closestPoint = getClosestPoint(reflectedIntersectionPoints);
	    	return calcColor(closestPoint);
	    }
		else {
    		return new Color(0,0,0);
    	}
	}

	private Color calcColor(GeoPoint gp) throws Exception {
		Color ambientLight = scene.getAmbientLight().getIntensity(gp.getPoint());
		Color emissionLight = gp.getGeometry().getEmission();
		Color diffuseLight = new Color(0, 0, 0);
	    Color specularLight = new Color(0, 0, 0); 
	    for (Light light: scene.getLights()) {
	    	if(!shaded(light.getL(gp.getPoint()), gp.getPoint(), gp.getGeometry().getNormal(gp.getPoint()))) {
	    		Color temp1= calcDiffusiveComp(gp.getGeometry().getMaterial().getKd(), gp.getGeometry().getNormal(gp.getPoint()).normalize(),
		    			light.getL(gp.getPoint()).scale(-1).normalize(),light.getIntensity(gp.getPoint()));
		    	diffuseLight=Light.colorAddColor(diffuseLight, temp1);
		    	Color temp2=calcSpecularComp(gp.getGeometry().getMaterial().getKs(), scene.getCamera().getP0().subtract(gp.getPoint()).normalize(),
		    			gp.getGeometry().getNormal(gp.getPoint()).normalize(), light.getL(gp.getPoint()).normalize(),
		    			gp.getGeometry().getMaterial().getShininess(), light.getIntensity(gp.getPoint()));
		    	specularLight=Light.colorAddColor(specularLight,temp2);
		    	//Color reflectedLight=Light.mulColorNum(calcReflect(gp.getGeometry().r), gp.getGeometry().getMaterial().get_kr());
	    	}	
	    }
	    Color temp3=Light.colorAddColor(emissionLight, ambientLight);
	    Color temp4=Light.colorAddColor(diffuseLight, specularLight);
	    return Light.colorAddColor(temp3, temp4);
	}
}
