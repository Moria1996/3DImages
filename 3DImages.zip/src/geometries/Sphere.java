package geometries;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import primitives.Material;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public class Sphere extends Geometry {
	//attributes for class Sphere
	private Point3D center;
	private double radius;
	public Sphere(double radius,Point3D center, Color emission) {//constructor
		this.center=new Point3D(center);
		this.radius=radius;
		this.emission=new Color(emission.getRGB());
		this.material=new Material();
	}
	public Sphere() {//default constructor
		this.center=new Point3D();
		this.radius=0;
		this.emission=new Color(0,0,0);
	}
	public Sphere(Sphere sphere) {//copy constructor
		this.center=new Point3D(sphere.center);
		this.radius=sphere.radius;
		this.emission=new Color(sphere.emission.getRGB());
	}
	//getters and setters
	public Point3D getCenter() {
		return this.center;
	}
	public void setCenter(Point3D center) {
		this.center = center;
	}
	public double getRadius() {
		return this.radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public List<Point3D> findIntersections(Ray ray) throws Exception {//return intersections points
		Vector u=new Vector(this.center.subtract(ray.getP00()));//calculate u
		List<Point3D> intersection=new ArrayList<>();
		Point3D p1,p2;
		double tm=ray.getDirection().normalize().dotProduct(u);//calculate tm
		double d=Math.sqrt(Math.pow(u.length(), 2)-Math.pow(tm, 2));//calculate d
		double th=Math.sqrt(Math.pow(this.radius, 2)-Math.pow(d, 2));//calculate th
		double t1=tm+th;//calculate t1
		double t2=tm-th;//calculate t2
		//if intersections points does not exist return null
		if(d>this.radius)
			return null;
		if(t1<=0&&t2<=0)
			return null;
		if(t1>0) {//add point 1 to the list if exist
			p1=new Point3D(ray.getP00().add(ray.getDirection().normalize().scale(t1)));
			intersection.add(p1);
		}
		if(t2>0) {//add point 2 to the list if exist
			p2=new Point3D(ray.getP00().add(ray.getDirection().normalize().scale(t2)));
			intersection.add(p2);
		}
		return intersection;
	}
	public Vector getNormal(Point3D point) throws Exception {//calculate and return normal
		Vector normal=new Vector(point.subtract(this.center).normalize());
		return normal;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sphere other = (Sphere) obj;
		if (center == null) {
			if (other.center != null)
				return false;
		} else if (!center.equals(other.center))
			return false;
		if (Double.doubleToLongBits(radius) != Double.doubleToLongBits(other.radius))
			return false;
		return true;
	}
	public String toString() {//toString method
		return "center: "+this.center+"radius: "+this.radius;
	}

	
	
}
