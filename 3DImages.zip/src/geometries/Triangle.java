package geometries;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import primitives.Coordinate;
import primitives.Material;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public class Triangle extends Geometry {
	//attributes for class Triangle
	private Point3D p1;
	private Point3D p2;
	private Point3D p3;
	public Triangle(Point3D p1, Point3D p2, Point3D p3, Color emission) throws Exception {//constructor
		if(p1.equals(p2)||p1.equals(p3)||p2.equals(p3))//if 2 of the points are equal
			throw new Exception ("triangle not valid. some of the points are equal");
		else if(p1.getX()==p2.getX()&&p3.getX()==p1.getX()&&
				p1.getY()==p2.getY()&&p1.getY()==p3.getY())//if 3 of the points in the same plane because x, y
			throw new Exception ("triangle not valid. all the x's and y's are equal.");
		else if(p1.getX()==p2.getX()&&p3.getX()==p1.getX()&&
				p1.getZ()==p2.getZ()&&p1.getZ()==p3.getZ())//if 3 of the points in the same plane because x, z
			throw new Exception ("triangle not valid. all the x's and z's are equal.");
		else if(p1.getZ()==p2.getZ()&&p3.getZ()==p1.getZ()&&
				p1.getY()==p2.getY()&&p1.getY()==p3.getY())//if 3 of the points in the same plane because z, y
			throw new Exception ("triangle not valid. all the z's and y's are equal.");
		else {
			this.p1=new Point3D(p1);
			this.p2=new Point3D(p2);
			this.p3=new Point3D(p3);
			this.emission=new Color(emission.getRGB());
			this.material=new Material();
		}	
	}
	public Triangle() {//default constructor
		Coordinate c1=new Coordinate ();
		Coordinate c2=new Coordinate (1);
		this.p1=new Point3D();
		this.p2=new Point3D(c2,c1,c1);
		this.p3=new Point3D(c1,c2,c1);
		this.emission=new Color(0,0,0);
		this.material=new Material();
	}
	public Triangle(Triangle triangle) {//copy constructor
		this.p1=new Point3D(triangle.p1);
		this.p2=new Point3D(triangle.p2);
		this.p3=new Point3D(triangle.p3);
		this.emission=new Color(triangle.emission.getRGB());
		this.material=new Material(triangle.material);
	}
	//getters and setters
	public Point3D getP1() {
		return this.p1;
	}
	public void setP1(Point3D p1) {
		this.p1 = p1;
	}
	public Point3D getP2() {
		return this.p2;
	}
	public void setP2(Point3D p2) {
		this.p2 = p2;
	}
	public Point3D getP3() {
		return this.p3;
	}
	public void setP3(Point3D p3) {
		this.p3 = p3;
	}
	public String toString() {//toString method
		return "p1: "+this.p1+"p2: "+this.p2+"p3: "+this.p3;
	}
	public List<Point3D> findIntersections(Ray ray) throws Exception {
		Plane plane=new Plane(this.p1,this.p2,this.p3,new Color(0,0,0));//create plane from triangle
		List<Point3D> intersection=new ArrayList<>();
		intersection=plane.findIntersections(ray);//get the intersection point with the plane
		//calculation
		Vector v1=new Vector(this.p1.subtract(ray.getP00()));
		Vector v2=new Vector(this.p2.subtract(ray.getP00()));
		Vector v3=new Vector(this.p3.subtract(ray.getP00()));
		Vector n1=new Vector(v1.crossProduct(v2).normalize());
		Vector n2=new Vector(v2.crossProduct(v3).normalize());
		Vector n3=new Vector(v3.crossProduct(v1).normalize());
		//check if the point is in the triangle
		if(ray.getDirection().dotProduct(n1)>0&&ray.getDirection().dotProduct(n2)>0&&ray.getDirection().dotProduct(n3)>0)
			return intersection;
		else if(ray.getDirection().dotProduct(n1)<0&&ray.getDirection().dotProduct(n2)<0&&ray.getDirection().dotProduct(n3)<0)
			return intersection;
		return null;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Triangle other = (Triangle) obj;
		if (p1 == null) {
			if (other.p1 != null)
				return false;
		} else if (!p1.equals(other.p1))
			return false;
		if (p2 == null) {
			if (other.p2 != null)
				return false;
		} else if (!p2.equals(other.p2))
			return false;
		if (p3 == null) {
			if (other.p3 != null)
				return false;
		} else if (!p3.equals(other.p3))
			return false;
		return true;
	}
	public Vector getNormal(Point3D point) throws Exception {//return normal
		//calculate normal
		Vector v1=new Vector(this.p2.subtract(this.p1));
		Vector v2=new Vector(this.p3.subtract(this.p1));
		Vector normal=new Vector(v1.crossProduct(v2)).normalize();
		return normal;
	}
	
	
	
	
	
}
