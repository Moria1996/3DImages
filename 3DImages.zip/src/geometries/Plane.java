package geometries;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import primitives.Material;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public class Plane extends Geometry {
	//attributes for class Plane
	private Point3D q;
	private Vector n;
	public Plane(Point3D q, Vector n, Color emission) {//constructor
		this.q=new Point3D(q);
		this.n=new Vector(n.normalize());
		this.emission=new Color(emission.getRGB());
		this.material=new Material();
	}
	public Plane() {//default constructor
		this.q=new Point3D();
		this.n=new Vector();
		this.emission=new Color(0,0,0);
		this.material=new Material();
	}
	public Plane(Plane plane) {//copy constructor
		this.q=new Point3D(plane.q);
		this.n=new Vector(plane.n);
		this.emission=new Color(plane.emission.getRGB());
		this.material=new Material(plane.material);
	}
	public Plane(Point3D p1, Point3D p2, Point3D p3, Color emission) throws Exception {//constructor that create plane from 3 Point3D
        // if p1=p2 or p1=p3 - an exception will be thrown
        Vector v1 = p1.subtract(p2);
        Vector v2 = p1.subtract(p3);
        // if the points are in the same line - X-product will throw an exception
        this.n = v1.crossProduct(v2).normalize();
        this.q = new Point3D(p1);
        this.emission=new Color(emission.getRGB());
    }
	//getters and setters
	public Point3D getQ() {
		return this.q;
	}
	public void setQ(Point3D q) {
		this.q = q;
	}
	public Vector getN() {
		return this.n;
	}
	public void setN(Vector n) {
		this.n = n;
	}
	public  List<Point3D> findIntersections(Ray ray) throws Exception{// return intersection point if exist
		if(this.q.equals(ray.getP00())||this.n.dotProduct(ray.getDirection())==0)
				return null;//if intersection point does not exist
		double t=this.n.dotProduct(this.q.subtract(ray.getP00()))/(this.n.dotProduct(ray.getDirection()));
		if(t<=0)
			return null;
		List<Point3D> intersection=new ArrayList<>();
		intersection.add(ray.getP00().add(ray.getDirection().scale(t)));
		return intersection;
	}
	public Vector getNormal(Point3D point) {//return normal
		return this.n;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Plane other = (Plane) obj;
		if (n == null) {
			if (other.n != null)
				return false;
		} else if (!n.equals(other.n))
			return false;
		if (q == null) {
			if (other.q != null)
				return false;
		} else if (!q.equals(other.q))
			return false;
		return true;
	}
	public String toString() {//toString method
		return "q: "+this.q+"n: "+this.n;
	}
	

	
	
	
	
	
	
	
	
	
	
}
