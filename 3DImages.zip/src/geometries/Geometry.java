package geometries;

import java.awt.Color;
import java.util.List;
import primitives.*;

public abstract class Geometry {
	//attribute
	protected Color emission;
	protected Material material;//not added to constructors
	//abstract method
	public abstract List<Point3D> findIntersections(Ray ray) throws Exception ;
	public abstract Vector getNormal(Point3D point) throws Exception;
	//getters and setters
	public Color getEmission() {
		return this.emission;			
	}
	public void setEmission(Color color) {
		this.emission=color;
	}
	public Material getMaterial() {
		return material;
	}
	public void setMaterial(Material material) {
		this.material = material;
	}
	
}
