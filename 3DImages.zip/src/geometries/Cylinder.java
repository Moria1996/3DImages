package geometries;

import java.awt.Color;
import java.util.List;
import java.util.Objects;

import primitives.Material;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public class Cylinder extends Geometry {
	//attributes for class Cylinder
	private double radius;
	private Ray axis;
	private double height;
	public Cylinder(double radius, Ray axis, double height, Color emission) {//constructor
		this.radius=radius;
		this.axis=new Ray(axis);
		this.height=height;
		this.emission=new Color(emission.getRGB());
		this.material=new Material();
	}
	public Cylinder() {//default constructor
		this.radius=0;
		this.axis=new Ray();
		this.height=0;
		this.emission=new Color(0,0,0);
		this.material=new Material();
	}
	public Cylinder(Cylinder cylinder) {//copy constructor
		this.radius=cylinder.radius;
		this.axis=new Ray(cylinder.axis);
		this.height=cylinder.height;
		this.emission=new Color(cylinder.emission.getRGB());
		this.material=new Material(cylinder.material);
	}
	//getters and setters
	public double getRadius() {
		return radius;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public Ray getAxis() {
		return axis;
	}
	public void setAxis(Ray axis) {
		this.axis = axis;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	@Override
	public List<Point3D> findIntersections(Ray ray) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Vector getNormal(Point3D point) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cylinder other = (Cylinder) obj;
		if (axis == null) {
			if (other.axis != null)
				return false;
		} else if (!axis.equals(other.axis))
			return false;
		if (Double.doubleToLongBits(height) != Double.doubleToLongBits(other.height))
			return false;
		if (Double.doubleToLongBits(radius) != Double.doubleToLongBits(other.radius))
			return false;
		return true;
	}
	public String toString() {//toString method
		return "radius: "+this.radius+", axis: "+this.axis+"height: "+this.height;
	}
	
	
	
	
	
	
	
	
}
