package primitives;

public class Ray {
	//attributes for class Ray
	private Point3D p00;
	private Vector direction;
	public Ray(Point3D p00, Vector direction) {//constructor
		this.p00=new Point3D(p00);
		this.direction=new Vector(direction);
	}
	public Ray() {//default constructor
		this.p00=new Point3D();
		this.direction=new Vector();
	}
	public Ray(Ray ray) {// copy constructor
		this.p00=new Point3D(ray.p00);
		this.direction=new Vector(ray.direction);
	}
	//getters and setters
	public Point3D getP00() {
		return this.p00;
	}
	public void setP00(Point3D p00) {
		this.p00 = p00;
	}
	public Vector getDirection() {
		return this.direction;
	}
	public void setDirection(Vector direction) {
		this.direction = direction;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ray other = (Ray) obj;
		if (direction == null) {
			if (other.direction != null)
				return false;
		} else if (!direction.equals(other.direction))
			return false;
		if (p00 == null) {
			if (other.p00 != null)
				return false;
		} else if (!p00.equals(other.p00))
			return false;
		return true;
	}
	public String toString() {//toString method
		return "point: "+this.p00+"direction: "+this.direction;
	}
	
	
	
	
	
	
	
	
}
