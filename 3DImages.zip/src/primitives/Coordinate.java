package primitives;

public class Coordinate {
	
	//attributes for class Coordinate
	private double coordinate;
	public Coordinate(double coordinate) {//constructor
		this.coordinate=coordinate;
	}
	public Coordinate() {//default constructor
		this.coordinate=0;
	}
	public Coordinate(Coordinate coordinate) {//copy constructor
		this.coordinate=coordinate.coordinate;
	}
	//getters and setters
	public double getCoordinate() {
		return this.coordinate;
	}
	public void setCoordinate(double coordinate) {
		this.coordinate=coordinate;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if(!(obj instanceof Coordinate))
			return false;
		return Util.isZero(this.coordinate - ((Coordinate)obj).coordinate);
	}
	public String toString() {//toString method
		return this.coordinate+"";
	}	
}
 