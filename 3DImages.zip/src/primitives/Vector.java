package primitives;

public class Vector {
	private Point3D head;//attribute for class Vector
	public Vector(Point3D head) {//constructor
		//if (Point3D.ZERO.equals(head))
			//throw new IllegalArgumentException("Zero vector is not allowed");
		this.head=new Point3D(head); 
	}
	public Vector() {//default constructor
		this.head=new Point3D(1,0,0);
	}
	public Vector(Vector vector) {//copy constructor
		this.head=new Point3D(vector.head);
	}
	public Vector(double x, double y, double z) {
		this.head=new Point3D(new Coordinate(x),new Coordinate(y),new Coordinate(z));
		//if (Point3D.ZERO.equals(this.head))
			//throw new IllegalArgumentException("Zero vector is not allowed");
	}
	//getters and setters
	public Point3D getHead() {
		return this.head;
	}
	public void setHead(Point3D head) {
		this.head = head;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vector other = (Vector) obj;
		if (head == null) {
			if (other.head != null)
				return false;
		} else if (!head.equals(other.head))
			return false;
		return true;
	}
	public boolean equals (Vector vector) {//equals method
		if(this.head.equals(vector.head))
			return true;
		return false;
	}
	public double length() {//calculate length of Vector
		double length=Math.pow(this.head.getX().getCoordinate(), 2);//calculate x^2
		length+=Math.pow(this.head.getY().getCoordinate(), 2);//calculate += y^2
		length+=Math.pow(this.head.getZ().getCoordinate(), 2);//calculate += z^2
		length=Math.sqrt(length);
		return length;
	}
	public Vector normalize() {//calculate unit vector 
		double length=this.length();//calculate length
		Coordinate unitX=new Coordinate(this.head.getX().getCoordinate()/length);// x/length
		Coordinate unitY=new Coordinate(this.head.getY().getCoordinate()/length);// y/length
		Coordinate unitZ=new Coordinate(this.head.getZ().getCoordinate()/length);// z/length
		Vector unit=new Vector(new Point3D(unitX,unitY,unitZ));
		return unit;
	}
	public Vector add(Vector other) throws Exception {//calculate sum of two Vectors
		if(this.equals(other.scale(-1)))//if other=this*(-1) throw Exception
			throw new Exception();
		else {
			Coordinate sumX=new Coordinate(this.head.getX().getCoordinate()+other.head.getX().getCoordinate());
			Coordinate sumY=new Coordinate(this.head.getY().getCoordinate()+other.head.getY().getCoordinate());
			Coordinate sumZ=new Coordinate(this.head.getZ().getCoordinate()+other.head.getZ().getCoordinate());
			Vector sumVectors=new Vector(new Point3D(sumX,sumY,sumZ));
			return sumVectors;
		}
		//calculates: x+x, y+y, z+z	
	}
	public Vector subtract(Vector other) throws Exception {//calculate Vector-Vector
		if(this.equals(other)) //if the 2 Vectors are equal throw Exception
			throw new Exception();	
		else {
			//calculates: x-x, y-y, z-z
			Coordinate subX=new Coordinate(this.head.getX().getCoordinate()-other.head.getX().getCoordinate());
			Coordinate subY=new Coordinate(this.head.getY().getCoordinate()-other.head.getY().getCoordinate());
			Coordinate subZ=new Coordinate(this.head.getZ().getCoordinate()-other.head.getZ().getCoordinate());
			Vector subVectors=new Vector(new Point3D(subX,subY,subZ));
			return subVectors;
		}
	}
	public Vector scale(double scalar) throws Exception {//calculates Vector * scalar
		if(scalar==0)//if scalar is - throw Exception
			throw new Exception();
		else {
			//calculates: x*scalar, y*scalar, z*scalar
			Coordinate mulScalarX=new Coordinate(this.head.getX().getCoordinate()*scalar);
			Coordinate mulScalarY=new Coordinate(this.head.getY().getCoordinate()*scalar);
			Coordinate mulScalarZ=new Coordinate(this.head.getZ().getCoordinate()*scalar);
			Vector scalarMulVector=new Vector(new Point3D(mulScalarX,mulScalarY,mulScalarZ));
			return scalarMulVector;
		}		
	}
	public double dotProduct(Vector other) {//calculates Vector * Vector - return double
		//calculates x*x+y*y+z*z
		double dotProductResult=this.head.getX().getCoordinate()*other.head.getX().getCoordinate();
		dotProductResult+=this.head.getY().getCoordinate()*other.head.getY().getCoordinate();
		dotProductResult+=this.head.getZ().getCoordinate()*other.head.getZ().getCoordinate();
		return dotProductResult;
	}
	public Vector crossProduct(Vector other) throws Exception {
		//calculates cross product
		Coordinate crossProductX=new Coordinate(this.head.getY().getCoordinate()*other.head.getZ().getCoordinate());
		crossProductX.setCoordinate(crossProductX.getCoordinate()-this.head.getZ().getCoordinate()*other.head.getY().getCoordinate());
		Coordinate crossProductY=new Coordinate(this.head.getZ().getCoordinate()*other.head.getX().getCoordinate());
		crossProductY.setCoordinate(crossProductY.getCoordinate()-this.head.getX().getCoordinate()*other.head.getZ().getCoordinate());
		Coordinate crossProductZ=new Coordinate(this.head.getX().getCoordinate()*other.head.getY().getCoordinate());
		crossProductZ.setCoordinate(crossProductZ.getCoordinate()-this.head.getY().getCoordinate()*other.head.getX().getCoordinate());
		Vector crossProductResult=new Vector(new Point3D(crossProductX,crossProductY,crossProductZ));
		if(crossProductResult.equals(new Vector(0,0,0)))
			throw new Exception();
		else
			return crossProductResult;
	}
	public String toString() {//toString method
		return "head: "+this.head;
	}	
}
