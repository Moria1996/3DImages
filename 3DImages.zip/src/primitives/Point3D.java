package primitives;

public class Point3D {
	//attributes for class Point3D
	private Coordinate x;
	private Coordinate y;
	private Coordinate z;
	//static point for (0,0,0)
	public static Point3D ZERO=new Point3D();

	//constructor
	public Point3D(Coordinate x, Coordinate y, Coordinate z) {
		this.x=new Coordinate(x);
		this.y=new Coordinate(y);
		this.z=new Coordinate(z);
	}
	public Point3D() {//default constructor
		this.x=new Coordinate();
		this.y=new Coordinate();
		this.z=new Coordinate();
	}
	public Point3D(Point3D point) {//copy constructor
		this.x=new Coordinate(point.x);
		this.y=new Coordinate(point.y);
		this.z=new Coordinate(point.z);
	}
	public Point3D(double x, double y, double z) {
		this.x=new Coordinate(x);
		this.y=new Coordinate(y);
		this.z=new Coordinate(z);
	}
	//getters and setters
	public Coordinate getX() {
		return this.x;
	}
	public void setX(Coordinate x) {
		this.x=x;
	}
	public Coordinate getY() {
		return this.y;
	}
	public void setY(Coordinate y) {
		this.y = y;
	}
	public Coordinate getZ() {
		return this.z;
	}
	public void setZ(Coordinate z) {
		this.z = z;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Point3D other = (Point3D) obj;
		if (x == null) {
			if (other.x != null)
				return false;
		} else if (!x.equals(other.x))
			return false;
		if (y == null) {
			if (other.y != null)
				return false;
		} else if (!y.equals(other.y))
			return false;
		if (z == null) {
			if (other.z != null)
				return false;
		} else if (!z.equals(other.z))
			return false;
		return true;
	}
	//public boolean equals(Point3D point) {//equals method
		//if(this.x.equals(point.x)&&this.y.equals(point.y)&&this.z.equals(point.z))
			//return true;
		//return false;
	//}
	public Point3D add(Vector v) {//method thats calculate Vector+ Point3D
		//create coordinates for newPoint using calculation
		Coordinate c1=new Coordinate(v.getHead().x.getCoordinate()+this.x.getCoordinate());
		Coordinate c2=new Coordinate(v.getHead().y.getCoordinate()+this.y.getCoordinate());
		Coordinate c3=new Coordinate(v.getHead().z.getCoordinate()+this.z.getCoordinate());
		Point3D resultPoint=new Point3D(c1,c2,c3);
		return resultPoint;
	}
	public Vector subtract(Point3D other) throws Exception {//method thats calculate the vector between 2 Points
		//create Coordinates for resultHead using calculation
		Coordinate x=new Coordinate(this.x.getCoordinate()-other.x.getCoordinate());
		Coordinate y=new Coordinate(this.y.getCoordinate()-other.y.getCoordinate());
		Coordinate z=new Coordinate(this.z.getCoordinate()-other.z.getCoordinate());
		Point3D resultHead=new Point3D(x,y,z);
		Vector resultVector=new Vector(resultHead);
		if(resultVector.equals(new Vector (0,0,0)))
			throw new Exception();
		else
			return resultVector;
	}
	public double distance(Point3D other) {//calculates distance between 2 Points
		double distance=Math.pow(this.x.getCoordinate()-other.x.getCoordinate(), 2);
		distance+=Math.pow(this.y.getCoordinate()-other.y.getCoordinate(), 2);
		distance+=Math.pow(this.z.getCoordinate()-other.z.getCoordinate(), 2);
		distance=Math.sqrt(distance);
		return distance;
	}
	public String toString() {//toString method
		return "("+this.x+", "+this.y+", "+this.z+")\n";
	}
}
